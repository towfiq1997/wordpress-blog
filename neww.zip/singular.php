<?ph


// Template Name : singular.php
//  Author : Obig



<div class="container">
   <div class="singular_section">
    <?php is_singular_page(){
           wp_nav_menu(array(
               'theme_location'=>'primary_menu',
               'menu_class'=>'flex flex_menu borderd',
               'item_wrap'=>'ul' ,
           ));


        <div class="slidea-show">
            <div class="single_slide">
                
            </div>
        </div>

    } ?>
   </div>
</div>