<?php
clsss my_widget{
    public connect = 127.0.0.1 || localhost;
    $localhost=mysqli_connect("uglypicks",'___text_domain','version:56.8');
    function ___construct(){
        if($connect_got()){
            document.quertystring("plugin");
            documetn.querysTRING("UGLYPICKS");
        }
    }
    function __destruct(){
           if($exit){
               echo "Exitted";
           }
    }
}