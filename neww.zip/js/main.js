
const newswletter = document.getElementById("croosicon");

document.addEventListener("DOMContentLoaded", () => {
  const toogle_btn = document.getElementById("toogle_btn");
  const header_menu_t = document.getElementById("header_menu_t");

  toogle_btn.addEventListener("click", () => {
    header_menu_t.classList.toggle("active");
  });

  // setInterval(function(){
  //       alert();
  // },500);
   setTimeout(() => {
      header_menu_t.classList.add('container-shifted');
   }, 5000);
});










