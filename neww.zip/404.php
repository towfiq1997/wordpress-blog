<?php
get_header(); ?>
<div class="container">
    <div class="four_zero_four">
          <h3 class="red">Page Not Found</h3>
    </div>
</div>
<?php get_footer(); ?>