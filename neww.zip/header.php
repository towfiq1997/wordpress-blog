<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="<?php bloginfo( 'charset'); ?>" />
    <title><?php wp_title(); ?></title>
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
    <?php wp_head(); ?>
    <style>
nav.header {
  min-height: 70px;
  color: white;
  box-shadow: rgb(100 100 111 / 20%) 0px 7px 29px 0px;
  margin-bottom: 38px;
  padding:0 20px;
}
nav.flex {
  justify-content: space-between;
}
.search-bar {
  position: relative;
}

.search-bar input {
  max-width: 150px;
  padding: 10px 15px;
  border: none;
  background: #d0dcf7;
  color: #0547d3;
  font-size: 15px;
  border-radius: 30px;
}

.search-bar i {
  color: black;
}
.search-bar input:focus {
  outline: none;
}
nav.header .logo h2 a {
  font-size: 30px;
  font-weight: bold;

}
.search-bar i {
  position: absolute;
  color: #333;
  top: 48%;
  transform: translateY(-50%);
  right: 18px;
  font-size: 12px;
  cursor: pointer;
}

nav.header.flex a {
  font-size: 18px;
  font-weight: 500;
}

nav.header.flex a > i {
  margin-right: 10px;
  font-size: 17px;
}

.header_nav_menu {
  min-height: 30px;
}

.header_nav_menu ul  {
  display: flex;
  justify-content: space-between;
  align-items:center;
}

.header_nav_menu ul li a {
  font-size: 20px;
  font-weight: bold;
  padding: 25px;
  position: relative;
}


    </style>
</head>

<body>
        <nav class="header flex">
            <div class="logo">
                <h2><a href="<?php get_home_url(); ?>"><?php echo get_bloginfo('name'); ?></a></h2>
            </div>
            <div class="toogle_menu" id="toogle_btn">
                <span class="bars"></span>
                <span class="bars"></span>
                <span class="bars"></span>
            </div>
            <div class="header_nav_menu" id="header_menu_t">
              <?php
                  wp_nav_menu(array(
                   'theme_location'=>'header_menu',
                  ));
               ?>
            </div>
            <div class="search-bar">
                <form action="" method="get">
                     <input type="text" name="s" value="<?php the_search_query(); ?>" id="" placeholder="Search.....">
                     <button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                </form>
            </div>
        </nav>