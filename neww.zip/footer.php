<footer class="uglypicks_footer py-4">
    <div class="ulwrapper flex-j-b container">
        <?php
        
        wp_nav_menu(array(
            'theme_location'=>'footer_menu',
            'menu_class'=>'contrainer',
            'item_wrap'=>'container_ul'
        ));
        
        
        ?>
       <ul>
            <li><a href="">Home</a></li>
            <li><a href="">About</a></li>
            <li><a href="">Contact</a></li>
        </ul>
        <ul class="social_icon flex">
           <li><a href="" class="fb"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
           <li><a href="" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
           <li><a href="" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
           <li><a href="" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
        </ul>
    </div>
</footer>
<?php wp_footer(); ?>
<!-- <div class="scroll-to-top" id="scroll-top">
    <a href="" class="scroll-top-btn"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
</div> -->
</body>
</html>